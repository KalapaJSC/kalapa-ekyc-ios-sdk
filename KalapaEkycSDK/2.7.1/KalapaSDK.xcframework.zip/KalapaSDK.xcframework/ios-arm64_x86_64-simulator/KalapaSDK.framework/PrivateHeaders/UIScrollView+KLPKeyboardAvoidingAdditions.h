#import <UIKit/UIKit.h>

@protocol KLPKeyboardAvoidingAdditionsOptions <NSObject>
- (BOOL)KLPKeyboardAvoiding_idealOffsetForViewAlwaysTop;
@end

@interface UIScrollView (KLPKeyboardAvoidingAdditions)
- (BOOL)KLPKeyboardAvoiding_focusNextTextField;
- (void)KLPKeyboardAvoiding_scrollToActiveTextField;

- (void)KLPKeyboardAvoiding_keyboardWillShow:(NSNotification*)notification;
- (void)KLPKeyboardAvoiding_keyboardWillHide:(NSNotification*)notification;
- (void)KLPKeyboardAvoiding_updateContentInset;
- (void)KLPKeyboardAvoiding_updateFromContentSizeChange;
- (void)KLPKeyboardAvoiding_assignTextDelegateForViewsBeneathView:(UIView*)view;
- (UIView*)KLPKeyboardAvoiding_findFirstResponderBeneathView:(UIView*)view;
-(CGSize)KLPKeyboardAvoiding_calculatedContentSizeFromSubviewFrames;
@end
